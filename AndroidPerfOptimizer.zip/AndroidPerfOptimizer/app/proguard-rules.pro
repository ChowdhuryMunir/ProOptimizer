# Keep ViewModel classes
-keep class com.perfoptimizer.viewmodel.** { *; }

# Keep data model classes used in LiveData
-keep class com.perfoptimizer.data.** { *; }

# AndroidX Navigation
-keepnames class androidx.navigation.fragment.NavHostFragment

# Material Components
-keep class com.google.android.material.** { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}
