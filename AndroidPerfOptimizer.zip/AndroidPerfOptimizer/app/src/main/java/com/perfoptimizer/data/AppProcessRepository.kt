package com.perfoptimizer.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager

/**
 * Repository for listing and killing background app processes.
 * Uses only ActivityManager — no heavy usage-stats permission required for basic listing.
 */
class AppProcessRepository(private val context: Context) {

    private val activityManager =
        context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val packageManager: PackageManager = context.packageManager

    data class AppProcess(
        val appName: String,
        val packageName: String,
        val pid: Int,
        val memoryKb: Long,       // approximate; 0 if unavailable
        val importance: Int       // ActivityManager.RunningAppProcessInfo importance level
    )

    /**
     * Returns a list of running app processes sorted by memory usage (highest first).
     * Excludes this app itself and pure system processes (importance >= 1000).
     */
    fun getRunningApps(): List<AppProcess> {
        val processes = activityManager.runningAppProcesses ?: return emptyList()

        // Batch-query memory info for all PIDs at once — more efficient than individual calls
        val pids = processes.map { it.pid }.toIntArray()
        val memInfoMap = try {
            val memArray = activityManager.getProcessMemoryInfo(pids)
            pids.zip(memArray).toMap()
        } catch (e: Exception) {
            emptyMap()
        }

        return processes
            .filter { proc ->
                // Skip this app's own process
                proc.pkgList?.none { it == context.packageName } != false &&
                // Show only foreground services, visible, cached — skip pure kernel processes
                proc.importance < ActivityManager.RunningAppProcessInfo.IMPORTANCE_GONE
            }
            .mapNotNull { proc ->
                val packageName = proc.pkgList?.firstOrNull() ?: return@mapNotNull null
                val appName = try {
                    val appInfo = packageManager.getApplicationInfo(packageName, 0)
                    packageManager.getApplicationLabel(appInfo).toString()
                } catch (e: PackageManager.NameNotFoundException) {
                    packageName // fallback to package name
                }

                val memInfo = memInfoMap[proc.pid]
                val memKb = memInfo?.totalPss?.toLong() ?: 0L

                AppProcess(
                    appName     = appName,
                    packageName = packageName,
                    pid         = proc.pid,
                    memoryKb    = memKb,
                    importance  = proc.importance
                )
            }
            .sortedByDescending { it.memoryKb }
    }

    /**
     * Returns true if this package is a system app that should NOT be killed.
     * We check the ApplicationInfo flags — FLAG_SYSTEM marks core OS packages.
     */
    fun isSystemApp(packageName: String): Boolean {
        return try {
            val flags = packageManager.getApplicationInfo(packageName, 0).flags
            (flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
        } catch (e: PackageManager.NameNotFoundException) {
            true // treat unknown as system to be safe
        }
    }

    /**
     * Kills a background process by package name.
     * Requires KILL_BACKGROUND_PROCESSES permission.
     * Will silently do nothing if the app is in the foreground (Android restriction).
     */
    fun killBackgroundProcess(packageName: String) {
        activityManager.killBackgroundProcesses(packageName)
    }
}
