package com.perfoptimizer.data

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import java.io.BufferedReader
import java.io.FileReader
import java.io.IOException

/**
 * Repository that reads system information directly from Android APIs and /proc filesystem.
 * All reads are synchronous and lightweight — no background services needed.
 * Designed to be polled every 3–5 seconds from a ViewModel coroutine.
 */
class SystemInfoRepository(private val context: Context) {

    private val activityManager =
        context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    // ── RAM ─────────────────────────────────────────────────────────────────

    data class RamInfo(
        val totalBytes: Long,
        val availableBytes: Long,
        val usedBytes: Long,
        val usedPercent: Int
    )

    fun getRamInfo(): RamInfo {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val total = memInfo.totalMem
        val available = memInfo.availMem
        val used = total - available
        val percent = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0

        return RamInfo(total, available, used, percent)
    }

    // ── CPU ─────────────────────────────────────────────────────────────────

    data class CpuInfo(val usagePercent: Int)

    // Stores previous /proc/stat tick counts for delta calculation
    private var prevIdle: Long = 0L
    private var prevTotal: Long = 0L

    /**
     * Reads /proc/stat to compute CPU usage since last call.
     * Returns 0 on first call (no previous sample to diff against).
     * /proc/stat format: cpu  user nice system idle iowait irq softirq
     */
    fun getCpuInfo(): CpuInfo {
        return try {
            val reader = BufferedReader(FileReader("/proc/stat"))
            val line = reader.readLine() // first line is aggregate "cpu"
            reader.close()

            val tokens = line.trim().split("\\s+".toRegex())
            // tokens[0] = "cpu", [1]=user [2]=nice [3]=system [4]=idle [5]=iowait [6]=irq [7]=softirq
            val user    = tokens[1].toLong()
            val nice    = tokens[2].toLong()
            val system  = tokens[3].toLong()
            val idle    = tokens[4].toLong()
            val iowait  = tokens[5].toLong()
            val irq     = tokens[6].toLong()
            val softirq = tokens[7].toLong()

            val currentIdle  = idle + iowait
            val currentTotal = user + nice + system + idle + iowait + irq + softirq

            val deltaIdle  = currentIdle  - prevIdle
            val deltaTotal = currentTotal - prevTotal

            val usage = if (deltaTotal > 0)
                (100 * (deltaTotal - deltaIdle) / deltaTotal).toInt()
            else 0

            prevIdle  = currentIdle
            prevTotal = currentTotal

            CpuInfo(usage.coerceIn(0, 100))
        } catch (e: IOException) {
            // /proc/stat unavailable — return 0 gracefully
            CpuInfo(0)
        }
    }

    // ── STORAGE ─────────────────────────────────────────────────────────────

    data class StorageInfo(
        val totalBytes: Long,
        val freeBytes: Long,
        val usedBytes: Long,
        val usedPercent: Int
    )

    fun getStorageInfo(): StorageInfo {
        val stat = StatFs(context.filesDir.absolutePath)
        val blockSize  = stat.blockSizeLong
        val total      = stat.blockCountLong * blockSize
        val free       = stat.availableBlocksLong * blockSize
        val used       = total - free
        val percent    = if (total > 0) ((used.toDouble() / total) * 100).toInt() else 0
        return StorageInfo(total, free, used, percent)
    }

    // ── CACHE SIZE ──────────────────────────────────────────────────────────

    /** Returns the size of this app's own cache directory in bytes. */
    fun getAppCacheSize(): Long = context.cacheDir.walkTopDown()
        .filter { it.isFile }
        .map { it.length() }
        .sum()

    /** Deletes this app's own cache files. Returns bytes freed. */
    fun clearAppCache(): Long {
        val freed = getAppCacheSize()
        context.cacheDir.deleteRecursively()
        context.cacheDir.mkdirs() // recreate empty dir
        return freed
    }
}
