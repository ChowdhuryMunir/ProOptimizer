package com.perfoptimizer.ui.apps

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.perfoptimizer.data.AppProcessRepository.AppProcess
import com.perfoptimizer.databinding.ItemAppProcessBinding
import com.perfoptimizer.utils.FormatUtils

/**
 * ListAdapter uses DiffUtil under the hood — only re-binds rows that actually changed.
 * This is the most memory-efficient RecyclerView pattern for low-RAM devices.
 */
class AppProcessAdapter(
    private val onStopClick: (AppProcess) -> Unit
) : ListAdapter<AppProcess, AppProcessAdapter.ViewHolder>(DIFF_CALLBACK) {

    inner class ViewHolder(private val binding: ItemAppProcessBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(process: AppProcess) {
            binding.tvAppName.text    = process.appName
            binding.tvPackageName.text = process.packageName
            binding.tvMemory.text     = if (process.memoryKb > 0)
                FormatUtils.formatKb(process.memoryKb)
            else
                "— MB"

            // Show importance as a readable label
            binding.tvImportance.text = importanceLabel(process.importance)

            binding.btnStop.setOnClickListener { onStopClick(process) }
        }

        private fun importanceLabel(importance: Int): String = when {
            importance <= 100 -> "Foreground"
            importance <= 130 -> "Visible"
            importance <= 200 -> "Service"
            importance <= 230 -> "Top Stopped"
            importance <= 300 -> "Background"
            else              -> "Cached"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAppProcessBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<AppProcess>() {
            // Use package name + pid as stable identity
            override fun areItemsTheSame(old: AppProcess, new: AppProcess) =
                old.packageName == new.packageName && old.pid == new.pid

            override fun areContentsTheSame(old: AppProcess, new: AppProcess) =
                old == new
        }
    }
}
