package com.perfoptimizer.ui.apps

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.perfoptimizer.databinding.FragmentAppsBinding
import com.perfoptimizer.viewmodel.AppsViewModel

/**
 * Displays currently running app processes in a RecyclerView.
 * Allows the user to stop non-system background apps after a confirmation dialog.
 */
class RunningAppsFragment : Fragment() {

    private var _binding: FragmentAppsBinding? = null
    private val binding get() = _binding!!

    // Fragment-scoped ViewModel — only alive while this fragment exists
    private val viewModel: AppsViewModel by viewModels()
    private lateinit var adapter: AppProcessAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAppsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeLiveData()
        viewModel.startPolling()

        binding.btnRefresh.setOnClickListener { viewModel.refreshNow() }
    }

    private fun setupRecyclerView() {
        adapter = AppProcessAdapter { process ->
            // Guard: do not offer to kill system apps
            if (viewModel.isSystemApp(process.packageName)) {
                Toast.makeText(
                    requireContext(),
                    "Cannot stop system apps",
                    Toast.LENGTH_SHORT
                ).show()
                return@AppProcessAdapter
            }

            // Show warning dialog before killing
            AlertDialog.Builder(requireContext())
                .setTitle("Stop App")
                .setMessage("Stop \"${process.appName}\"?\n\nThis may interrupt ongoing tasks.")
                .setPositiveButton("Stop") { _, _ ->
                    viewModel.killProcess(process.appName, process.packageName)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // setHasFixedSize: RecyclerView doesn't need to re-measure when items change
        binding.recyclerApps.setHasFixedSize(true)
        binding.recyclerApps.adapter = adapter
    }

    private fun observeLiveData() {
        viewModel.apps.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            binding.tvAppCount.text = "${list.size} running apps"
            binding.tvEmptyState.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            binding.progressLoading.visibility = if (loading) View.VISIBLE else View.GONE
        }

        viewModel.killResult.observe(viewLifecycleOwner) { (appName, success) ->
            val msg = if (success) "Stopped: $appName" else "Cannot stop system app: $appName"
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStop() {
        super.onStop()
        viewModel.stopPolling() // pause when not visible — saves CPU
    }

    override fun onStart() {
        super.onStart()
        viewModel.startPolling()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
