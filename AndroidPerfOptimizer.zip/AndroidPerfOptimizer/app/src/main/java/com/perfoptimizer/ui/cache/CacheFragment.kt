package com.perfoptimizer.ui.cache

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.perfoptimizer.databinding.FragmentCacheBinding
import com.perfoptimizer.utils.FormatUtils
import com.perfoptimizer.viewmodel.MainViewModel

/**
 * Cache Cleaner screen.
 *
 * On Android 8+, apps cannot programmatically clear other apps' caches without
 * a system signature permission. This screen therefore:
 *   1. Clears this app's own cache (instantaneous, no permission needed)
 *   2. Provides a deep-link to system Storage Settings so the user can
 *      clear all cached data in one tap themselves.
 */
class CacheFragment : Fragment() {

    private var _binding: FragmentCacheBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCacheBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.startPolling()

        // Show this app's current cache size
        viewModel.cacheSize.observe(viewLifecycleOwner) { bytes ->
            binding.tvAppCacheSize.text = "App cache: ${FormatUtils.formatBytes(bytes)}"
        }

        // Clear this app's own cache
        binding.btnClearAppCache.setOnClickListener {
            viewModel.clearCache()
        }

        viewModel.cacheClearResult.observe(viewLifecycleOwner) { freed ->
            val msg = if (freed > 0)
                "Cleared ${FormatUtils.formatBytes(freed)}"
            else
                "Cache already empty"
            Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
        }

        // Deep-link to system storage settings (works on all Android 8+ devices)
        binding.btnOpenStorageSettings.setOnClickListener {
            val intent = Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            // Fallback: if ACTION_INTERNAL_STORAGE_SETTINGS is not available, open app settings
            if (intent.resolveActivity(requireContext().packageManager) != null) {
                startActivity(intent)
            } else {
                val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", requireContext().packageName, null)
                }
                startActivity(fallback)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
