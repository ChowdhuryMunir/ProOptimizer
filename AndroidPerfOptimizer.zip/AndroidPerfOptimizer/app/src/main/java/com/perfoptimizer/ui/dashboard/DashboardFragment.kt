package com.perfoptimizer.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.perfoptimizer.databinding.FragmentDashboardBinding
import com.perfoptimizer.utils.FormatUtils
import com.perfoptimizer.viewmodel.MainViewModel

/**
 * Dashboard fragment — shows live RAM, CPU, and Storage gauges.
 * Uses activityViewModels so the ViewModel (and its polling loop)
 * is shared with other fragments and survives navigation.
 */
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    // Shared ViewModel — stays alive across fragment transactions
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeLiveData()
        viewModel.startPolling()
    }

    private fun observeLiveData() {

        // ── RAM card ──────────────────────────────────────────────────────
        viewModel.ramInfo.observe(viewLifecycleOwner) { info ->
            binding.tvRamUsed.text    = FormatUtils.formatBytes(info.usedBytes)
            binding.tvRamAvail.text   = FormatUtils.formatBytes(info.availableBytes)
            binding.tvRamTotal.text   = FormatUtils.formatBytes(info.totalBytes)
            binding.tvRamPercent.text = "${info.usedPercent}%"
            binding.progressRam.progress = info.usedPercent

            // Color-code severity: green → yellow → red
            binding.progressRam.progressTintList =
                progressColor(info.usedPercent, requireContext())
        }

        // ── CPU card ──────────────────────────────────────────────────────
        viewModel.cpuInfo.observe(viewLifecycleOwner) { info ->
            binding.tvCpuPercent.text = "${info.usagePercent}%"
            binding.progressCpu.progress = info.usagePercent
            binding.progressCpu.progressTintList =
                progressColor(info.usagePercent, requireContext())
        }

        // ── Storage card ──────────────────────────────────────────────────
        viewModel.storageInfo.observe(viewLifecycleOwner) { info ->
            binding.tvStorageUsed.text  = FormatUtils.formatBytes(info.usedBytes)
            binding.tvStorageFree.text  = FormatUtils.formatBytes(info.freeBytes)
            binding.tvStorageTotal.text = FormatUtils.formatBytes(info.totalBytes)
            binding.tvStoragePercent.text = "${info.usedPercent}%"
            binding.progressStorage.progress = info.usedPercent
            binding.progressStorage.progressTintList =
                progressColor(info.usedPercent, requireContext())
        }
    }

    /** Returns a ColorStateList based on usage severity. */
    private fun progressColor(
        percent: Int,
        context: android.content.Context
    ): android.content.res.ColorStateList {
        val colorRes = when {
            percent < 60 -> android.R.color.holo_green_dark
            percent < 80 -> android.R.color.holo_orange_dark
            else         -> android.R.color.holo_red_dark
        }
        return android.content.res.ColorStateList.valueOf(
            androidx.core.content.ContextCompat.getColor(context, colorRes)
        )
    }

    // Avoid memory leaks: null out binding reference when view is destroyed
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
