package com.perfoptimizer.ui.storage

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.perfoptimizer.databinding.FragmentStorageBinding
import com.perfoptimizer.utils.FormatUtils
import com.perfoptimizer.viewmodel.MainViewModel

/**
 * Storage detail screen — shows a breakdown of total / used / free internal storage.
 * Shares the MainViewModel (activityViewModels) so no duplicate polling occurs.
 */
class StorageFragment : Fragment() {

    private var _binding: FragmentStorageBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentStorageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.startPolling() // safe to call repeatedly — idempotent

        viewModel.storageInfo.observe(viewLifecycleOwner) { info ->
            binding.tvTotalStorage.text = FormatUtils.formatBytes(info.totalBytes)
            binding.tvUsedStorage.text  = FormatUtils.formatBytes(info.usedBytes)
            binding.tvFreeStorage.text  = FormatUtils.formatBytes(info.freeBytes)
            binding.tvStoragePercent.text = "${info.usedPercent}% used"
            binding.progressStorage.progress = info.usedPercent

            // Draw a simple two-segment breakdown bar
            binding.progressStorageDetail.progress = info.usedPercent
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
