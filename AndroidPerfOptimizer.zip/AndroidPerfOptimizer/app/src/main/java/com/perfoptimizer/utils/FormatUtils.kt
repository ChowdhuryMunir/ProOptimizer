package com.perfoptimizer.utils

import java.util.Locale

/**
 * Utility functions for formatting bytes into human-readable strings.
 * Kept as top-level functions for zero-overhead access.
 */
object FormatUtils {

    fun formatBytes(bytes: Long): String {
        return when {
            bytes >= 1_073_741_824L -> String.format(Locale.US, "%.1f GB", bytes / 1_073_741_824.0)
            bytes >= 1_048_576L     -> String.format(Locale.US, "%.1f MB", bytes / 1_048_576.0)
            bytes >= 1_024L         -> String.format(Locale.US, "%.1f KB", bytes / 1_024.0)
            else                    -> "$bytes B"
        }
    }

    fun formatKb(kb: Long): String = formatBytes(kb * 1024L)
}
