package com.perfoptimizer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.perfoptimizer.data.AppProcessRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ViewModel for the Running Apps screen.
 * Process listing is done on IO dispatcher because getProcessMemoryInfo() can block briefly.
 */
class AppsViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AppProcessRepository(application)

    private val _apps = MutableLiveData<List<AppProcessRepository.AppProcess>>()
    private val _killResult = MutableLiveData<Pair<String, Boolean>>() // appName, success
    private val _isLoading = MutableLiveData<Boolean>()

    val apps:       LiveData<List<AppProcessRepository.AppProcess>> = _apps
    val killResult: LiveData<Pair<String, Boolean>>                 = _killResult
    val isLoading:  LiveData<Boolean>                               = _isLoading

    private var pollingJob: Job? = null

    fun startPolling() {
        if (pollingJob?.isActive == true) return
        pollingJob = viewModelScope.launch {
            while (isActive) {
                _isLoading.value = true
                val list = withContext(Dispatchers.IO) { repo.getRunningApps() }
                _apps.value = list
                _isLoading.value = false
                delay(5_000L) // slightly longer interval — list changes less frequently
            }
        }
    }

    fun stopPolling() {
        pollingJob?.cancel()
    }

    fun refreshNow() {
        viewModelScope.launch {
            _isLoading.value = true
            val list = withContext(Dispatchers.IO) { repo.getRunningApps() }
            _apps.value = list
            _isLoading.value = false
        }
    }

    /**
     * Attempts to kill a background process.
     * Will not kill system apps — validated by AppProcessRepository.
     */
    fun killProcess(appName: String, packageName: String) {
        viewModelScope.launch {
            if (repo.isSystemApp(packageName)) {
                _killResult.value = Pair(appName, false)
                return@launch
            }
            withContext(Dispatchers.IO) {
                repo.killBackgroundProcess(packageName)
            }
            _killResult.value = Pair(appName, true)
            // Refresh list after a short delay to reflect the kill
            delay(800L)
            refreshNow()
        }
    }

    fun isSystemApp(packageName: String): Boolean = repo.isSystemApp(packageName)

    override fun onCleared() {
        super.onCleared()
        stopPolling()
    }
}
