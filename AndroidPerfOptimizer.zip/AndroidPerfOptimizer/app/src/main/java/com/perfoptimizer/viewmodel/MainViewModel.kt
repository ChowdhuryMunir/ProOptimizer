package com.perfoptimizer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.perfoptimizer.data.SystemInfoRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * MainViewModel owns the polling loop for RAM, CPU, and Storage data.
 * Survives configuration changes; the UI observes LiveData objects.
 * Uses a single coroutine (no thread pool) — lightweight on low-RAM devices.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = SystemInfoRepository(application)

    // LiveData observed by Dashboard / Storage fragments
    private val _ramInfo  = MutableLiveData<SystemInfoRepository.RamInfo>()
    private val _cpuInfo  = MutableLiveData<SystemInfoRepository.CpuInfo>()
    private val _storageInfo = MutableLiveData<SystemInfoRepository.StorageInfo>()
    private val _cacheSize   = MutableLiveData<Long>()
    private val _cacheClearResult = MutableLiveData<Long>() // bytes freed

    val ramInfo:      LiveData<SystemInfoRepository.RamInfo>     = _ramInfo
    val cpuInfo:      LiveData<SystemInfoRepository.CpuInfo>     = _cpuInfo
    val storageInfo:  LiveData<SystemInfoRepository.StorageInfo> = _storageInfo
    val cacheSize:    LiveData<Long>                             = _cacheSize
    val cacheClearResult: LiveData<Long>                         = _cacheClearResult

    // Refresh interval — 4 seconds balances freshness and battery
    private val refreshIntervalMs = 4_000L
    private var pollingJob: Job? = null

    fun startPolling() {
        if (pollingJob?.isActive == true) return  // already running
        pollingJob = viewModelScope.launch {
            while (isActive) {
                // Each read is fast (<1 ms) — safe on main thread via Dispatchers.Main
                _ramInfo.value     = repo.getRamInfo()
                _cpuInfo.value     = repo.getCpuInfo()
                _storageInfo.value = repo.getStorageInfo()
                _cacheSize.value   = repo.getAppCacheSize()
                delay(refreshIntervalMs)
            }
        }
    }

    fun stopPolling() {
        pollingJob?.cancel()
    }

    /** One-shot: clears app cache and reports bytes freed via LiveData. */
    fun clearCache() {
        viewModelScope.launch {
            val freed = repo.clearAppCache()
            _cacheClearResult.value = freed
            _cacheSize.value = repo.getAppCacheSize()
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopPolling()
    }
}
